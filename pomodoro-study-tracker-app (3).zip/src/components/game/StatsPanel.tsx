"use client";

import { useEffect, useState } from "react";
import { Award, CalendarDays, Clock, Flame, ListOrdered, Target, TrendingUp, Trophy, X, Zap } from "lucide-react";

export interface StatsData {
  today: { totalSeconds: number; sessions: number; tasks: { name: string; seconds: number }[] };
  week: { key: string; label: string; totalSeconds: number; sessions: number; isToday: boolean }[];
  streak: number;
  history: {
    date: string;
    totalSeconds: number;
    sessions: number;
    topTask: string;
    tasks: { name: string; seconds: number }[];
    tasksDone: number;
  }[];
  topTasks: { name: string; seconds: number }[];
  highScores: {
    id: number;
    taskName: string;
    mode: string;
    plannedMinutes: number;
    actualSeconds: number;
    score: number;
    createdAt: string;
  }[];
  allTimeSeconds: number;
  totalSessions: number;
}

type Tab = "today" | "week" | "records" | "history" | "best";

export function fmtDuration(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

export function fmtDateLabel(key: string): string {
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86_400_000);
  if (key === today.toISOString().slice(0, 10)) return "Today";
  if (key === yesterday.toISOString().slice(0, 10)) return "Yesterday";
  return new Date(`${key}T00:00:00`).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

const TABS: { id: Tab; label: string; icon: typeof Clock }[] = [
  { id: "today", label: "Today", icon: Target },
  { id: "week", label: "Week", icon: TrendingUp },
  { id: "records", label: "Records", icon: ListOrdered },
  { id: "best", label: "Best", icon: Trophy },
];

interface Props {
  data: StatsData | null;
  onClose: () => void;
}

export default function StatsPanel({ data, onClose }: Props) {
  const [tab, setTab] = useState<Tab>("today");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key.toLowerCase() === "t") {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const weekMax = Math.max(60, ...(data?.week.map((d) => d.totalSeconds) ?? [60]));
  const taskMax = Math.max(60, ...(data?.today.tasks.map((t) => t.seconds) ?? [60]));
  const weekTotal = data?.week.reduce((s, d) => s + d.totalSeconds, 0) ?? 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true">
      <button
        aria-label="Close stats"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />
      <div className="anim-pop relative flex max-h-[88dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-[#0d0b18]/95 shadow-[0_40px_120px_rgba(0,0,0,0.6)] sm:rounded-3xl">
        {/* header */}
        <div className="flex items-center justify-between gap-3 border-b border-white/8 px-5 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-white">Study Analytics</h2>
            <p className="text-xs text-white/45">
              {data ? `${data.totalSessions} sessions · ${fmtDuration(data.allTimeSeconds)} all-time` : "Loading..."}
            </p>
          </div>
          <button
            onClick={onClose}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 active:scale-90"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* tabs */}
        <div className="grid grid-cols-5 gap-1.5 px-4 pt-3">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-xs font-bold transition active:scale-95 ${
                tab === t.id
                  ? "bg-amber-400/15 text-amber-300 shadow-[inset_0_0_0_1px_rgba(251,191,36,0.35)]"
                  : "bg-white/4 text-white/50 hover:bg-white/8"
              }`}
            >
              <t.icon size={13} />
              {t.label}
            </button>
          ))}
        </div>

        {/* content */}
        <div className="no-scrollbar flex-1 overflow-y-auto px-5 py-4">
          {!data ? (
            <div className="grid place-items-center py-16 text-white/40">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/15 border-t-amber-400" />
            </div>
          ) : (
            <>
              {tab === "today" && (
                <div className="space-y-5">
                  <div className="grid grid-cols-3 gap-2.5">
                    <div className="rounded-2xl border border-white/8 bg-white/4 p-3.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-widest text-white/40 uppercase">
                        <Clock size={11} /> Focused
                      </div>
                      <div className="font-mono2 mt-1.5 text-xl font-bold text-amber-300">{fmtDuration(data.today.totalSeconds)}</div>
                    </div>
                    <div className="rounded-2xl border border-white/8 bg-white/4 p-3.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-widest text-white/40 uppercase">
                        <Zap size={11} /> Sessions
                      </div>
                      <div className="font-mono2 mt-1.5 text-xl font-bold text-cyan-300">{data.today.sessions}</div>
                    </div>
                    <div className="rounded-2xl border border-white/8 bg-white/4 p-3.5">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-widest text-white/40 uppercase">
                        <Flame size={11} /> Streak
                      </div>
                      <div className="font-mono2 mt-1.5 text-xl font-bold text-pink-300">{data.streak}d</div>
                    </div>
                  </div>

                  <div>
                    <div className="mb-2.5 flex items-center gap-2 text-xs font-bold tracking-widest text-white/45 uppercase">
                      <Target size={12} /> Today&apos;s missions
                    </div>
                    {data.today.tasks.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-white/40">
                        No sessions yet today. Start your first focus run.
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {data.today.tasks.map((t) => (
                          <div key={t.name}>
                            <div className="mb-1 flex items-baseline justify-between gap-3">
                              <span className="truncate text-sm font-semibold text-white/85">{t.name}</span>
                              <span className="font-mono2 text-xs text-white/50">{fmtDuration(t.seconds)}</span>
                            </div>
                            <div className="h-2 overflow-hidden rounded-full bg-white/8">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-amber-400 to-pink-500 transition-[width] duration-700 ease-out"
                                style={{ width: `${Math.max(4, (t.seconds / taskMax) * 100)}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {data.today.totalSeconds > 0 && (
                    <div className="flex items-center gap-2 rounded-2xl border border-emerald-400/20 bg-emerald-400/8 px-4 py-3 text-sm text-emerald-300">
                      <Flame size={15} className="shrink-0" />
                      {data.streak > 0
                        ? `${data.streak}-day streak — keep the flame alive!`
                        : "Session logged. Come back tomorrow to build a streak."}
                    </div>
                  )}
                </div>
              )}

              {tab === "week" && (
                <div className="space-y-5">
                  <div className="rounded-2xl border border-white/8 bg-white/4 p-4">
                    <div className="mb-1 text-xs font-bold tracking-widest text-white/45 uppercase">Last 7 days</div>
                    <div className="font-mono2 text-2xl font-bold text-white">{fmtDuration(weekTotal)}</div>
                    <div className="text-xs text-white/40">total focus time this week</div>
                  </div>
                  <div className="flex h-44 items-end justify-between gap-2 px-1">
                    {data.week.map((d) => {
                      const h = Math.max(3, (d.totalSeconds / weekMax) * 100);
                      return (
                        <div key={d.key} className="group flex h-full flex-1 flex-col items-center justify-end gap-1.5">
                          <span className="font-mono2 text-[10px] text-white/45 opacity-0 transition group-hover:opacity-100">
                            {fmtDuration(d.totalSeconds)}
                          </span>
                          <div
                            className={`w-full max-w-9 rounded-t-lg transition-[height] duration-700 ease-out ${
                              d.isToday
                                ? "bg-gradient-to-t from-amber-500 to-amber-300 shadow-[0_0_18px_rgba(251,191,36,0.4)]"
                                : d.totalSeconds > 0
                                  ? "bg-gradient-to-t from-violet-600 to-fuchsia-400"
                                  : "bg-white/8"
                            }`}
                            style={{ height: `${h}%` }}
                          />
                          <span className={`text-[10px] font-bold ${d.isToday ? "text-amber-300" : "text-white/40"}`}>
                            {d.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {tab === "records" && (
                <div className="space-y-2">
                  {data.history.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-white/40">
                      No records yet. Your study history will appear here by date.
                    </div>
                  ) : (
                    data.history.map((h, i) => (
                      <div
                        key={h.date}
                        className={`flex items-center gap-3 rounded-2xl border px-4 py-3 ${
                          i === 0 ? "border-amber-400/25 bg-amber-400/6" : "border-white/8 bg-white/3"
                        }`}
                      >
                        <div
                          className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${
                            i === 0 ? "bg-amber-400/15 text-amber-300" : "bg-white/6 text-white/50"
                          }`}
                        >
                          <CalendarDays size={17} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-bold text-white/90">{fmtDateLabel(h.date)}</div>
                          <div className="truncate text-xs text-white/45">
                            {h.sessions} session{h.sessions === 1 ? "" : "s"}
                            {h.topTask ? ` · ${h.topTask}` : ""}
                          </div>
                        </div>
                        <div className="font-mono2 shrink-0 text-sm font-bold text-cyan-300">{fmtDuration(h.totalSeconds)}</div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {tab === "history" && (
                <div className="space-y-3">
                  {data.history.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-white/40">
                      No history yet. Finish a session and your daily breakdown will appear here.
                    </div>
                  ) : (
                    data.history.map((h, i) => {
                      const max = Math.max(60, ...h.tasks.map((t) => t.seconds));
                      return (
                        <div
                          key={h.date}
                          className={`rounded-2xl border p-4 ${
                            i === 0 ? "border-amber-400/25 bg-amber-400/6" : "border-white/8 bg-white/3"
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-2.5">
                              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/6 text-white/50">
                                <CalendarDays size={16} />
                              </span>
                              <div>
                                <div className="text-sm font-bold text-white/90">{fmtDateLabel(h.date)}</div>
                                <div className="text-[11px] text-white/45">
                                  {h.sessions} session{h.sessions === 1 ? "" : "s"}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-mono2 text-base font-bold text-cyan-300">{fmtDuration(h.totalSeconds)}</div>
                              <div className="text-[10px] font-bold text-emerald-300">
                                {h.tasksDone} task{h.tasksDone === 1 ? "" : "s"} done
                              </div>
                            </div>
                          </div>

                          {h.tasks.length > 0 && (
                            <div className="mt-3 space-y-1.5">
                              {h.tasks.map((t) => (
                                <div key={t.name} className="flex items-center gap-2">
                                  <span className="min-w-0 flex-1 truncate text-[11px] font-semibold text-white/60">{t.name}</span>
                                  <div className="h-1.5 w-16 overflow-hidden rounded-full bg-white/8 sm:w-20">
                                    <div
                                      className="h-full rounded-full bg-gradient-to-r from-amber-400 to-pink-500"
                                      style={{ width: `${Math.max(5, (t.seconds / max) * 100)}%` }}
                                    />
                                  </div>
                                  <span className="font-mono2 w-12 shrink-0 text-right text-[11px] text-white/50">
                                    {fmtDuration(t.seconds)}
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {tab === "best" && (
                <div className="space-y-2">
                  {data.highScores.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-white/40">
                      No high scores yet. Finish a session to set one.
                    </div>
                  ) : (
                    data.highScores.map((h, i) => {
                      const medal = i === 0 ? "text-amber-300" : i === 1 ? "text-slate-300" : i === 2 ? "text-amber-600" : "text-white/35";
                      return (
                        <div
                          key={h.id}
                          className={`flex items-center gap-3 rounded-2xl border px-4 py-3 ${
                            i === 0 ? "border-amber-400/30 bg-amber-400/8" : "border-white/8 bg-white/3"
                          }`}
                        >
                          <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/5 ${medal}`}>
                            <Award size={17} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-sm font-bold text-white/90">{h.taskName}</div>
                            <div className="text-xs text-white/45">
                              {h.mode === "timer" ? "Pomodoro Timer" : "Countdown"} · {fmtDuration(h.actualSeconds)} ·{" "}
                              {new Date(h.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                            </div>
                          </div>
                          <div className="font-mono2 shrink-0 text-base font-bold text-amber-300">{h.score.toLocaleString()}</div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
