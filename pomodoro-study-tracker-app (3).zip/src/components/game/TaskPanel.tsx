"use client";

import { useEffect, useState } from "react";
import {
  Check,
  ChevronLeft,
  Clock,
  ListChecks,
  Minus,
  Play,
  Plus,
  Timer as TimerIcon,
  Trash2,
  X,
} from "lucide-react";
import type { TaskItem, TimerMode } from "@/lib/types";

const COUNTDOWN_PRESETS = [5, 10, 15, 20, 25, 30, 45, 60, 90, 120];
const TIMER_PRESETS = [10, 15, 20, 25, 30, 45, 60];

interface Props {
  tasks: TaskItem[];
  onClose: () => void;
  onAdd: (name: string) => void;
  onToggle: (id: number, done: boolean) => void;
  onDelete: (id: number) => void;
  onStart: (task: TaskItem, mode: TimerMode, minutes: number) => void;
}

export default function TaskPanel({ tasks, onClose, onAdd, onToggle, onDelete, onStart }: Props) {
  const [view, setView] = useState<"list" | "mode" | "time">("list");
  const [chosen, setChosen] = useState<TaskItem | null>(null);
  const [mode, setMode] = useState<TimerMode>("timer");
  const [minutes, setMinutes] = useState(25);
  const [newTask, setNewTask] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        if (view === "time") setView("mode");
        else if (view === "mode") setView("list");
        else onClose();
      }
      if (view === "time" && (e.key === "Enter" || e.key === " ")) {
        e.preventDefault();
        if (chosen) onStart(chosen, mode, minutes);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [view, chosen, mode, minutes, onClose, onStart]);

  const remaining = tasks.filter((t) => !t.done);
  const done = tasks.filter((t) => t.done);
  const presets = mode === "timer" ? TIMER_PRESETS : COUNTDOWN_PRESETS;

  const submitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newTask.trim();
    if (!name) return;
    onAdd(name);
    setNewTask("");
  };

  const openModeSelect = (t: TaskItem) => {
    setChosen(t);
    setMode("timer");
    setMinutes(25);
    setView("mode");
  };

  const pickMode = (m: TimerMode) => {
    setMode(m);
    setMinutes(m === "timer" ? 25 : 25);
    setView("time");
  };

  const clampMinutes = (v: number) => Math.max(1, Math.min(240, Math.round(v)));

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true">
      <button aria-label="Close tasks" onClick={onClose} className="absolute inset-0 bg-black/70 backdrop-blur-sm" />

      <div className="anim-pop relative flex max-h-[88dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border border-white/10 bg-[#0d0b18]/95 shadow-[0_40px_120px_rgba(0,0,0,0.6)] sm:rounded-3xl">
        {/* ---------------- LIST VIEW ---------------- */}
        {view === "list" && (
          <>
            <div className="flex items-center justify-between gap-3 border-b border-white/8 px-5 py-4">
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-cyan-400/15 text-cyan-300">
                  <ListChecks size={17} />
                </span>
                <div>
                  <h2 className="font-display text-lg font-bold text-white">My Tasks</h2>
                  <p className="text-xs text-white/45">
                    {remaining.length} remaining · {done.length} done
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 active:scale-90"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>

            {/* add a new task */}
            <div className="border-b border-white/8 px-5 py-3.5">
              <form onSubmit={submitAdd} className="flex gap-2">
                <input
                  value={newTask}
                  onChange={(e) => setNewTask(e.target.value)}
                  placeholder="Add a new task..."
                  maxLength={80}
                  className="min-w-0 flex-1 rounded-xl border border-white/12 bg-white/5 px-3.5 py-2.5 text-sm font-semibold text-white placeholder-white/25 transition focus:border-cyan-400/60"
                />
                <button
                  type="submit"
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-cyan-400/20 text-cyan-300 transition hover:bg-cyan-400/30 active:scale-90"
                  aria-label="Add task"
                >
                  <Plus size={17} />
                </button>
              </form>
            </div>

            <div className="no-scrollbar flex-1 space-y-2 overflow-y-auto px-5 py-4">
              <div className="text-[10px] font-bold tracking-[0.25em] text-white/35 uppercase">Your remaining tasks</div>

              {tasks.length === 0 && (
                <div className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-white/40">
                  No tasks yet. Add a new task above — then tap it to pick Timer or Countdown.
                </div>
              )}

              {remaining.map((t) => (
                <div key={t.id} className="flex items-center gap-2 rounded-2xl border border-white/8 bg-white/3 p-2 pl-3.5">
                  <button onClick={() => openModeSelect(t)} className="min-w-0 flex-1 py-1 text-left transition active:scale-[0.98]">
                    <div className="truncate text-sm font-bold text-white/90">{t.name}</div>
                    <div className="text-[11px] font-semibold text-cyan-300/70">Tap to start a session</div>
                  </button>
                  <button
                    onClick={() => onToggle(t.id, true)}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/40 transition hover:border-emerald-400/40 hover:text-emerald-300 active:scale-90"
                    aria-label={`Mark ${t.name} done`}
                  >
                    <Check size={15} />
                  </button>
                  <button
                    onClick={() => onDelete(t.id)}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white/30 transition hover:bg-red-400/10 hover:text-red-400 active:scale-90"
                    aria-label={`Delete ${t.name}`}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}

              {done.length > 0 && (
                <div className="pt-2">
                  <div className="mb-2 text-[10px] font-bold tracking-[0.25em] text-white/35 uppercase">Completed</div>
                  <div className="space-y-1.5">
                    {done.map((t) => (
                      <div key={t.id} className="flex items-center gap-2 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 opacity-70">
                        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-400/15 text-emerald-300">
                          <Check size={12} />
                        </span>
                        <span className="min-w-0 flex-1 truncate text-sm font-semibold text-white/50 line-through">{t.name}</span>
                        <button
                          onClick={() => onToggle(t.id, false)}
                          className="shrink-0 rounded-lg px-2 py-1 text-[11px] font-bold text-white/40 transition hover:bg-white/8 hover:text-white active:scale-95"
                        >
                          Undo
                        </button>
                        <button
                          onClick={() => onDelete(t.id)}
                          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-white/25 transition hover:text-red-400 active:scale-90"
                          aria-label={`Delete ${t.name}`}
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* ---------------- MODE SELECT ---------------- */}
        {view === "mode" && chosen && (
          <>
            <div className="flex items-center justify-between gap-3 border-b border-white/8 px-5 py-4">
              <button
                onClick={() => setView("list")}
                className="flex items-center gap-1 text-xs font-bold text-white/50 transition hover:text-white active:scale-95"
              >
                <ChevronLeft size={16} /> All tasks
              </button>
              <span className="font-mono2 text-[10px] text-white/30">ESC</span>
            </div>

            <div className="no-scrollbar flex-1 overflow-y-auto px-5 py-5">
              <div className="mb-1 text-center text-[10px] font-bold tracking-[0.3em] text-white/40 uppercase">Selected task</div>
              <div className="font-display mb-5 truncate text-center text-xl font-bold text-white">{chosen.name}</div>

              <div className="mb-4 text-center">
                <span className="text-sm font-bold text-white/70">Select Timer or Countdown</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => pickMode("timer")}
                  className="rounded-2xl border border-violet-400/60 bg-violet-400/10 p-4 text-left shadow-[0_0_28px_rgba(167,139,250,0.18)] transition hover:bg-violet-400/15 active:scale-95"
                >
                  <TimerIcon size={22} className="text-violet-300" />
                  <div className="font-display mt-3 text-sm font-bold">Timer</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-white/45">Pomodoro focus rounds with breaks</div>
                </button>

                <button
                  onClick={() => pickMode("countdown")}
                  className="rounded-2xl border border-amber-400/60 bg-amber-400/10 p-4 text-left shadow-[0_0_28px_rgba(251,191,36,0.15)] transition hover:bg-amber-400/15 active:scale-95"
                >
                  <Clock size={22} className="text-amber-300" />
                  <div className="font-display mt-3 text-sm font-bold">Countdown</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-white/45">Straight countdown, your call</div>
                </button>
              </div>
            </div>
          </>
        )}

        {/* ---------------- TIME SELECT ---------------- */}
        {view === "time" && chosen && (
          <>
            <div className="flex items-center justify-between gap-3 border-b border-white/8 px-5 py-4">
              <button
                onClick={() => setView("mode")}
                className="flex items-center gap-1 text-xs font-bold text-white/50 transition hover:text-white active:scale-95"
              >
                <ChevronLeft size={16} /> Mode
              </button>
              <span className="font-mono2 text-[10px] text-white/30">ESC</span>
            </div>

            <div className="no-scrollbar flex-1 overflow-y-auto px-5 py-5">
              <div className="mb-1 text-center text-[10px] font-bold tracking-[0.3em] text-white/40 uppercase">
                {chosen.name} · {mode === "timer" ? "Timer" : "Countdown"}
              </div>
              <div className="mb-5 text-center">
                <span className="font-display text-2xl font-bold text-white">
                  {mode === "timer" ? "How much time per round?" : "How much time?"}
                </span>
              </div>

              {/* stepper */}
              <div className="mx-auto mb-5 flex w-full max-w-xs items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/4 p-2.5">
                <button
                  onClick={() => setMinutes((m) => clampMinutes(m - 5))}
                  className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 active:scale-90"
                  aria-label="Less time"
                >
                  <Minus size={17} />
                </button>
                <div className="text-center">
                  <span className="font-mono2 text-4xl font-black text-white tabular-nums">{minutes}</span>
                  <div className="text-[10px] font-bold tracking-[0.25em] text-white/40 uppercase">minutes</div>
                </div>
                <button
                  onClick={() => setMinutes((m) => clampMinutes(m + 5))}
                  className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 active:scale-90"
                  aria-label="More time"
                >
                  <Plus size={17} />
                </button>
              </div>

              {/* presets */}
              <div className="mx-auto flex max-w-xs flex-wrap justify-center gap-1.5">
                {presets.map((p) => (
                  <button
                    key={p}
                    onClick={() => setMinutes(p)}
                    className={`rounded-xl px-3 py-2 font-mono2 text-xs font-bold transition active:scale-90 ${
                      minutes === p
                        ? mode === "timer"
                          ? "bg-violet-400 text-black shadow-[0_0_18px_rgba(167,139,250,0.35)]"
                          : "bg-amber-400 text-black shadow-[0_0_18px_rgba(251,191,36,0.35)]"
                        : "border border-white/10 bg-white/5 text-white/60 hover:bg-white/10"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>

              {mode === "timer" && (
                <p className="mt-4 text-center text-[11px] text-white/40">
                  {minutes}-minute focus rounds · 5-minute breaks · 4 rounds
                </p>
              )}

              <button
                onClick={() => onStart(chosen, mode, minutes)}
                className="mx-auto mt-6 flex w-full max-w-xs items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 font-display text-lg font-black tracking-wide text-black shadow-[0_10px_40px_rgba(251,146,60,0.35)] transition hover:brightness-110 active:scale-95"
              >
                <Play size={19} className="fill-black" /> OK — START
              </button>
              <p className="font-mono2 mt-3 text-center text-[10px] tracking-[0.2em] text-white/30">ENTER STARTS THE CLOCK</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
