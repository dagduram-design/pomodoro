"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Award,
  Brain,
  Check,
  ChevronLeft,
  ClipboardList,
  Clock,
  Coffee,
  Flame,
  HardDrive,
  Home,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Timer as TimerIcon,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import FXCanvas, { FXHandle, sfx } from "./fx";
import TimerRing, { RingHandle } from "./TimerRing";
import StatsPanel, { fmtDuration, type StatsData } from "./StatsPanel";
import TaskPanel from "./TaskPanel";
import type { TaskItem, TimerMode } from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  Constants & types                                                  */
/* ------------------------------------------------------------------ */

type Phase = "menu" | "setup" | "focus" | "paused" | "break" | "summary";

const POMODORO_BREAK = 5 * 60;
const POMODORO_ROUNDS = 4;
const BASE_PPS = 2; // points per second at combo x1
const MAX_COMBO = 3;
const MILESTONE = 300; // seconds between milestone bonuses

const DURATIONS = [5, 10, 15, 20, 25, 30, 45, 60, 90, 120];
const TIMER_PRESETS = [10, 15, 20, 25, 30, 45, 60];

interface Summary {
  taskName: string;
  taskId: number | null;
  taskDone: boolean;
  mode: TimerMode;
  plannedMinutes: number;
  actualSeconds: number;
  completed: boolean;
  score: number;
  bonus: number;
  saved: boolean;
  newHigh: boolean;
}

interface Pop {
  id: number;
  text: string;
  bad: boolean;
  x: number;
  y: number;
}

/* ------------------------------------------------------------------ */
/*  CountUp — animated number for the summary screen                   */
/* ------------------------------------------------------------------ */

function CountUp({ value, className }: { value: number; className?: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / 1300);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <span className={className}>{n.toLocaleString()}</span>;
}

/* ------------------------------------------------------------------ */
/*  StudyGame                                                          */
/* ------------------------------------------------------------------ */

export default function StudyGame() {
  const [phase, setPhase] = useState<Phase>("menu");
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [showTasks, setShowTasks] = useState(false);
  const [taskName, setTaskName] = useState("");
  const [mode, setMode] = useState<TimerMode>("timer");
  const [durationMin, setDurationMin] = useState(25);
  const [pomoMinutes, setPomoMinutes] = useState(25);
  const [round, setRound] = useState(1);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [bestCombo, setBestCombo] = useState(1);
  const [muted, setMuted] = useState(false);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [showStats, setShowStats] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [pops, setPops] = useState<Pop[]>([]);
  const [flash, setFlash] = useState<{ key: number; color: "red" | "green" }>({ key: 0, color: "green" });

  const fxRef = useRef<FXHandle | null>(null);
  const ringRef = useRef<RingHandle | null>(null);
  const ringBoxRef = useRef<HTMLDivElement | null>(null);
  const shakeRef = useRef<HTMLDivElement | null>(null);
  const intensityRef = useRef(0.7);
  const phaseRef = useRef<Phase>("menu");
  const pausedFromRef = useRef<"focus" | "break">("focus");
  const shownScoreRef = useRef(-1);
  const popId = useRef(0);
  const taskIdRef = useRef<number | null>(null);

  const engine = useRef({
    mode: "timer" as TimerMode,
    taskId: null as number | null,
    focusSeconds: 1500,
    round: 1,
    remaining: 0,
    total: 1,
    focusElapsed: 0,
    roundElapsed: 0,
    plannedSeconds: 1,
    score: 0,
    combo: 1,
    comboT: 0,
    nextMilestone: MILESTONE,
    raf: 0,
    last: 0,
  });

  /* ------------------------- helpers ------------------------- */

  const goPhase = useCallback((p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  }, []);

  const pop = useCallback((text: string, bad = false) => {
    const id = ++popId.current;
    setPops((p) => [...p.slice(-4), { id, text, bad, x: 50 + (Math.random() * 26 - 13), y: 8 + Math.random() * 18 }]);
    window.setTimeout(() => setPops((p) => p.filter((pp) => pp.id !== id)), 1250);
  }, []);

  const doFlash = useCallback((color: "red" | "green") => {
    setFlash((f) => ({ key: f.key + 1, color }));
  }, []);

  const loadStats = useCallback(async (): Promise<StatsData | null> => {
    try {
      const res = await fetch("/api/stats", { cache: "no-store" });
      if (!res.ok) throw new Error("bad response");
      const data = (await res.json()) as StatsData;
      setStats(data);
      try {
        localStorage.setItem("ff-stats", JSON.stringify(data));
      } catch {
        /* ignore */
      }
      return data;
    } catch {
      try {
        const cached = localStorage.getItem("ff-stats");
        if (cached) {
          const data = JSON.parse(cached) as StatsData;
          setStats(data);
          return data;
        }
      } catch {
        /* ignore */
      }
      return null;
    }
  }, []);

  const loadTasks = useCallback(async () => {
    try {
      const res = await fetch("/api/tasks", { cache: "no-store" });
      if (res.ok) setTasks((await res.json()) as TaskItem[]);
    } catch {
      /* ignore */
    }
  }, []);

  /* ------------------------- session flow ------------------------- */

  const beginFocus = useCallback(() => {
    sfx.unlock();
    sfx.start();
    const e = engine.current;
    cancelAnimationFrame(e.raf);
    e.mode = mode;
    e.taskId = taskIdRef.current;
    e.score = 0;
    e.combo = 1;
    e.comboT = 0;
    e.focusElapsed = 0;
    e.roundElapsed = 0;
    e.round = 1;
    if (mode === "timer") {
      const focus = Math.max(60, Math.min(180 * 60, pomoMinutes * 60));
      e.focusSeconds = focus;
      e.remaining = focus;
      e.total = focus;
      e.plannedSeconds = focus * POMODORO_ROUNDS;
    } else {
      e.remaining = durationMin * 60;
      e.total = e.remaining;
      e.plannedSeconds = e.remaining;
    }
    e.nextMilestone = MILESTONE;
    shownScoreRef.current = -1;
    setScore(0);
    setCombo(1);
    setBestCombo(1);
    setRound(1);
    intensityRef.current = 1.8;
    goPhase("focus");
    e.last = performance.now();
    e.raf = requestAnimationFrame(tick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, durationMin, pomoMinutes, goPhase]);

  const completeSession = useCallback(
    async (completed: boolean) => {
      const e = engine.current;
      cancelAnimationFrame(e.raf);
      const bonus = completed ? Math.round((e.plannedSeconds / 60) * 20 * e.combo) : 0;
      e.score += bonus;
      const finalScore = Math.floor(e.score);
      const secs = Math.max(1, Math.round(e.focusElapsed));
      const task = taskName.trim() || "Deep Work";
      const payload = {
        taskName: task,
        taskId: e.taskId,
        mode: e.mode,
        plannedMinutes: Math.max(1, Math.round(e.plannedSeconds / 60)),
        actualSeconds: secs,
        completed,
        score: finalScore,
      };
      setTaskName(task);
      setSummary({ ...payload, bonus, saved: false, newHigh: false, taskDone: false });
      shownScoreRef.current = finalScore;
      setScore(finalScore);
      intensityRef.current = 3;
      window.setTimeout(() => {
        if (phaseRef.current === "summary") intensityRef.current = 1.2;
      }, 2400);
      sfx.complete();
      fxRef.current?.shake(8);
      const cx = window.innerWidth / 2;
      const cy = window.innerHeight * 0.32;
      fxRef.current?.burst(cx, cy, 130, 1.7);
      window.setTimeout(() => fxRef.current?.burst(cx - window.innerWidth * 0.24, cy + 90, 70, 1.25), 260);
      window.setTimeout(() => fxRef.current?.burst(cx + window.innerWidth * 0.24, cy + 90, 70, 1.25), 480);
      goPhase("summary");

      let savedId: number | null = null;
      try {
        const res = await fetch("/api/sessions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const row = (await res.json()) as { id?: number };
          savedId = row.id ?? null;
          setSummary((s) => (s ? { ...s, saved: true } : s));
        }
      } catch {
        /* offline — summary still shows */
      }
      const data = await loadStats();
      if (data && savedId != null) {
        setSummary((s) => (s ? { ...s, newHigh: data.highScores.some((h) => h.id === savedId) } : s));
      }
    },
    [taskName, goPhase, loadStats],
  );

  const completeRef = useRef(completeSession);
  useEffect(() => {
    completeRef.current = completeSession;
  });

  const pauseSession = useCallback(() => {
    if (phaseRef.current !== "focus" && phaseRef.current !== "break") return;
    const e = engine.current;
    pausedFromRef.current = phaseRef.current;
    cancelAnimationFrame(e.raf);
    sfx.pause();
    fxRef.current?.shake(9);
    doFlash("red");
    if (e.combo > 1) {
      sfx.comboLost();
      pop("COMBO LOST", true);
    }
    e.combo = 1;
    setCombo(1);
    intensityRef.current = 0.25;
    goPhase("paused");
  }, [goPhase, pop, doFlash]);

  const pauseRef = useRef(pauseSession);
  useEffect(() => {
    pauseRef.current = pauseSession;
  });

  const resumeSession = useCallback(() => {
    const e = engine.current;
    sfx.resume();
    intensityRef.current = pausedFromRef.current === "break" ? 1 : 1.8;
    goPhase(pausedFromRef.current);
    e.last = performance.now();
    e.raf = requestAnimationFrame(tick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [goPhase]);

  const advanceRound = useCallback(() => {
    const e = engine.current;
    cancelAnimationFrame(e.raf);
    e.round += 1;
    setRound(e.round);
    e.remaining = e.focusSeconds;
    e.total = e.focusSeconds;
    e.roundElapsed = 0;
    e.nextMilestone = MILESTONE;
    sfx.start();
    intensityRef.current = 1.8;
    pop(`ROUND ${e.round}`);
    fxRef.current?.shake(4);
    goPhase("focus");
    e.last = performance.now();
    e.raf = requestAnimationFrame(tick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [goPhase, pop]);

  const quitToMenu = useCallback(() => {
    cancelAnimationFrame(engine.current.raf);
    intensityRef.current = 0.7;
    goPhase("menu");
  }, [goPhase]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      sfx.unlock();
      sfx.setEnabled(!next);
      try {
        localStorage.setItem("ff-muted", next ? "1" : "0");
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  /* ------------------------- tasks ------------------------- */

  const addTask = useCallback(async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;

    // Optimistic: show it instantly at the top of the remaining list.
    const tempId = -Date.now();
    const optimistic: TaskItem = { id: tempId, name: trimmed, done: false, createdAt: new Date().toISOString() };
    setTasks((ts) => [optimistic, ...ts]);

    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: trimmed }),
      });
      if (res.ok) {
        const task = (await res.json()) as TaskItem;
        setTasks((ts) => ts.map((t) => (t.id === tempId ? task : t)));
      } else {
        setTasks((ts) => ts.filter((t) => t.id !== tempId));
      }
    } catch {
      setTasks((ts) => ts.filter((t) => t.id !== tempId));
    }
  }, []);

  const toggleTask = useCallback(async (id: number, done: boolean) => {
    setTasks((ts) => ts.map((t) => (t.id === id ? { ...t, done } : t)));
    try {
      await fetch(`/api/tasks/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ done }),
      });
    } catch {
      /* ignore */
    }
  }, []);

  const deleteTask = useCallback(async (id: number) => {
    setTasks((ts) => ts.filter((t) => t.id !== id));
    try {
      await fetch(`/api/tasks/${id}`, { method: "DELETE" });
    } catch {
      /* ignore */
    }
  }, []);

  const startTask = useCallback(
    (task: TaskItem, m: TimerMode, dur: number) => {
      sfx.click();
      setTaskName(task.name);
      setMode(m);
      setDurationMin(dur);
      setPomoMinutes(dur);
      taskIdRef.current = task.id;
      setShowTasks(false);
      beginFocus();
    },
    [beginFocus],
  );

  const markTaskDone = useCallback(async () => {
    if (!summary || summary.taskId == null || summary.taskDone) return;
    try {
      const res = await fetch(`/api/tasks/${summary.taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ done: true }),
      });
      if (res.ok) {
        setSummary((s) => (s ? { ...s, taskDone: true } : s));
        setTasks((ts) => ts.map((t) => (t.id === summary.taskId ? { ...t, done: true } : t)));
        sfx.milestone();
        pop("TASK COMPLETED");
      }
    } catch {
      /* ignore */
    }
  }, [summary, pop]);

  /* ------------------------- the timer loop ------------------------- */

  const tick = useCallback(
    (now: number) => {
      const e = engine.current;
      const dt = Math.min(0.1, (now - e.last) / 1000);
      e.last = now;
      const ph = phaseRef.current;

      if (ph === "focus") {
        e.remaining -= dt;
        e.focusElapsed += dt;
        e.roundElapsed += dt;
        e.score += BASE_PPS * e.combo * dt;
        e.comboT += dt;

        if (e.comboT >= 60 && e.combo < MAX_COMBO) {
          e.comboT = 0;
          e.combo = Math.min(MAX_COMBO, Math.round((e.combo + 0.25) * 100) / 100);
          setCombo(e.combo);
          setBestCombo((b) => Math.max(b, e.combo));
          sfx.comboUp();
          pop(`COMBO x${e.combo.toFixed(2)}`);
        }

        if (e.roundElapsed >= e.nextMilestone) {
          e.nextMilestone += MILESTONE;
          const bonus = Math.round(50 * e.combo);
          e.score += bonus;
          sfx.milestone();
          fxRef.current?.shake(5);
          const box = ringBoxRef.current;
          if (box) {
            const r = box.getBoundingClientRect();
            fxRef.current?.burst(r.left + r.width / 2, r.top + r.height / 2, 55, 1.15);
          }
          doFlash("green");
          pop(`+${bonus} BONUS`);
        }

        const sc = Math.floor(e.score);
        if (sc !== shownScoreRef.current) {
          shownScoreRef.current = sc;
          setScore(sc);
        }

        ringRef.current?.set(e.remaining, e.total, e.focusElapsed);

        if (e.remaining <= 0) {
          e.remaining = 0;
          ringRef.current?.set(0, e.total, e.focusElapsed);
          if (e.mode === "timer" && e.round < POMODORO_ROUNDS) {
            e.remaining = POMODORO_BREAK;
            e.total = POMODORO_BREAK;
            e.roundElapsed = 0;
            e.nextMilestone = MILESTONE;
            sfx.breakStart();
            intensityRef.current = 1;
            pop("BREAK TIME");
            goPhase("break");
            e.last = performance.now();
            e.raf = requestAnimationFrame(tick);
          } else {
            completeRef.current(true);
          }
          return;
        }
      } else if (ph === "break") {
        e.remaining -= dt;
        ringRef.current?.set(e.remaining, e.total, e.focusElapsed);
        if (e.remaining <= 0) {
          e.remaining = 0;
          advanceRound();
          return;
        }
      }

      e.raf = requestAnimationFrame(tick);
    },
    [goPhase, pop, doFlash, advanceRound],
  );

  /* ------------------------- effects ------------------------- */

  // Keep the ring in sync when a phase (re)mounts it
  useEffect(() => {
    if (phase === "focus" || phase === "break" || phase === "paused") {
      const e = engine.current;
      ringRef.current?.set(Math.max(0, e.remaining), e.total, e.focusElapsed);
    }
  }, [phase]);

  // Audio unlock + mute pref + load local data
  useEffect(() => {
    const unlock = () => sfx.unlock();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    try {
      if (localStorage.getItem("ff-muted") === "1") {
        setMuted(true);
        sfx.setEnabled(false);
      }
    } catch {
      /* ignore */
    }
    void loadStats();
    void loadTasks();
  }, [loadStats, loadTasks]);

  // Auto-pause when the tab is hidden
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) pauseRef.current();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  // Keyboard controls
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const k = ev.key.toLowerCase();
      const target = ev.target as HTMLElement | null;

      if (k === "m") {
        toggleMute();
        return;
      }
      if (showStats || showTasks) return; // panels handle their own keys

      const inInput = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
      if (inInput) {
        if (ev.key === "Enter") {
          ev.preventDefault();
          if (phase === "setup") {
            target?.blur();
            taskIdRef.current = null;
            beginFocus();
          }
        }
        if (ev.key === "Escape") (target as HTMLInputElement).blur();
        return;
      }

      if ((ev.key === " " || ev.key === "Enter") && target && target.tagName === "BUTTON") {
        target.blur();
      }
      if (ev.key === " ") ev.preventDefault();

      if (k === "t") {
        sfx.click();
        setShowStats(true);
        return;
      }

      switch (phase) {
        case "menu":
          if (k === " " || k === "enter") {
            sfx.click();
            goPhase("setup");
          } else if (k === "b") {
            sfx.click();
            setShowTasks(true);
          }
          break;
        case "setup":
          if (k === "1") setMode("timer");
          else if (k === "2") setMode("countdown");
          else if (k === "enter") {
            taskIdRef.current = null;
            beginFocus();
          } else if (k === "escape") goPhase("menu");
          break;
        case "focus":
          if (k === " " || k === "p" || k === "escape") pauseSession();
          break;
        case "paused":
          if (k === " " || k === "p" || k === "enter") resumeSession();
          else if (k === "r") completeSession(false);
          else if (k === "escape") quitToMenu();
          break;
        case "break":
          if (k === " ") advanceRound();
          break;
        case "summary":
          if (k === "r" || k === " " || k === "enter") beginFocus();
          else if (k === "escape") quitToMenu();
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    phase,
    showStats,
    showTasks,
    beginFocus,
    pauseSession,
    resumeSession,
    advanceRound,
    completeSession,
    quitToMenu,
    toggleMute,
    goPhase,
  ]);

  /* ------------------------- derived ------------------------- */

  const todaySecs = stats?.today.totalSeconds ?? 0;
  const inSession = phase === "focus" || phase === "break" || phase === "paused";
  const ringVariant = phase === "break" ? "cyan" : mode === "timer" ? "violet" : "amber";
  const ringLabel =
    phase === "break"
      ? "BREAK"
      : mode === "timer"
        ? `POMODORO · ROUND ${round}`
        : phase === "paused"
          ? "PAUSED"
          : "FOCUS";
  const displayTask = taskName.trim() || "Deep Work";
  const remainingTasks = tasks.filter((t) => !t.done).length;

  /* ------------------------- render ------------------------- */

  return (
    <div
      className="fixed inset-0 overflow-hidden bg-[#07060e] font-sans text-white select-none"
      style={{ touchAction: "manipulation" }}
    >
      {/* aurora backdrop */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.035)_1px,transparent_1px)] bg-[size:44px_44px] [mask-image:radial-gradient(ellipse_at_center,black_25%,transparent_72%)]" />
        <div className="absolute -top-40 left-1/2 h-[30rem] w-[30rem] -translate-x-1/2 rounded-full bg-violet-600/22 blur-[130px]" />
        <div className="absolute -right-16 -bottom-24 h-[24rem] w-[24rem] rounded-full bg-amber-500/12 blur-[120px]" />
        <div className="absolute -bottom-24 -left-16 h-[22rem] w-[22rem] rounded-full bg-cyan-500/12 blur-[120px]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(0,0,0,0.5)_100%)]" />
      </div>

      {/* shaken game layer */}
      <div ref={shakeRef} className="relative z-10 mx-auto flex h-full w-full max-w-md flex-col px-5 py-5 sm:max-w-lg">
        {/* screen flash */}
        {flash.key > 0 && (
          <div
            key={flash.key}
            className={`flash-anim pointer-events-none absolute inset-0 z-30 ${
              flash.color === "red" ? "bg-red-500/12" : "bg-emerald-400/10"
            }`}
          />
        )}

        {/* floating score pops */}
        <div className="pointer-events-none absolute inset-x-0 top-14 z-30">
          {pops.map((p) => (
            <span
              key={p.id}
              className={`pop-float font-mono2 absolute text-lg font-black ${p.bad ? "text-red-400" : "text-emerald-300"}`}
              style={{ left: `${p.x}%`, top: p.y, textShadow: "0 2px 14px rgba(0,0,0,0.7)" }}
            >
              {p.text}
            </span>
          ))}
        </div>

        {/* ================= MENU ================= */}
        {phase === "menu" && (
          <div className="anim-pop flex flex-1 flex-col py-2">
            {/* local data chip */}
            <div className="flex items-center justify-between">
              <div className="glass flex items-center gap-2 rounded-full px-4 py-2.5">
                <HardDrive size={13} className="text-emerald-300" />
                <span className="text-xs font-bold text-white/70">Saved on this device</span>
              </div>
              <span className="font-mono2 text-[10px] tracking-[0.2em] text-white/30 uppercase">Local mode</span>
            </div>

            <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
              <div className="anim-float relative">
                <div className="absolute -inset-9 rounded-full bg-gradient-to-tr from-amber-500/25 via-fuchsia-500/20 to-cyan-400/25 blur-2xl" />
                <div className="relative grid h-24 w-24 place-items-center rounded-[1.8rem] border border-white/15 bg-gradient-to-br from-amber-400/20 to-violet-500/20 shadow-[0_0_60px_rgba(167,139,250,0.35)]">
                  <Brain className="text-amber-300" size={42} />
                  <div className="anim-spin-slow absolute -inset-2.5 rounded-[2.1rem] border border-dashed border-white/15" />
                </div>
              </div>

              <div>
                <h1 className="font-display text-gradient text-5xl font-black tracking-tight sm:text-6xl">FOCUS FORGE</h1>
                <p className="mt-2 text-sm text-white/50">Train your attention. Forge your records.</p>
              </div>

              {todaySecs > 0 && stats && (
                <div className="glass anim-pop flex items-center gap-4 rounded-2xl px-5 py-3">
                  <div className="flex items-center gap-1.5">
                    <Clock size={14} className="text-amber-300" />
                    <span className="font-mono2 text-sm font-bold text-amber-300">{fmtDuration(todaySecs)}</span>
                  </div>
                  <span className="h-4 w-px bg-white/15" />
                  <div className="flex items-center gap-1.5">
                    <Zap size={14} className="text-cyan-300" />
                    <span className="font-mono2 text-sm font-bold text-cyan-300">{stats.today.sessions}</span>
                  </div>
                  <span className="h-4 w-px bg-white/15" />
                  <div className="flex items-center gap-1.5">
                    <Flame size={14} className="text-pink-400" />
                    <span className="font-mono2 text-sm font-bold text-pink-300">{stats.streak}d</span>
                  </div>
                </div>
              )}

              <div className="w-full max-w-xs">
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.unlock();
                    sfx.click();
                    goPhase("setup");
                  }}
                  className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 font-display text-lg font-black tracking-wide text-black shadow-[0_10px_40px_rgba(251,146,60,0.4)] transition hover:brightness-110 active:scale-95"
                >
                  <span className="relative flex items-center justify-center gap-2">
                    <Play size={20} className="fill-black" /> START FOCUSING
                  </span>
                  <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                </button>
                <p className="font-mono2 mt-2.5 text-[10px] tracking-[0.25em] text-white/35">SPACE / TAP</p>
              </div>

              <div className="flex gap-2.5">
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    setShowTasks(true);
                  }}
                  className="glass relative flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-white/70 transition hover:bg-white/10 active:scale-95"
                >
                  <ClipboardList size={14} className="text-cyan-300" /> Tasks
                  {remainingTasks > 0 && (
                    <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-cyan-400 px-1 text-[10px] font-black text-black shadow-[0_0_12px_rgba(34,211,238,0.5)]">
                      {remainingTasks}
                    </span>
                  )}
                </button>
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    setShowStats(true);
                  }}
                  className="glass flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-white/70 transition hover:bg-white/10 active:scale-95"
                >
                  <Trophy size={14} className="text-amber-300" /> Stats &amp; Records
                </button>
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    toggleMute();
                  }}
                  className="glass grid h-10 w-10 place-items-center rounded-xl text-white/70 transition hover:bg-white/10 active:scale-95"
                  aria-label={muted ? "Unmute" : "Mute"}
                >
                  {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </button>
              </div>

              {stats && stats.highScores.length > 0 && (
                <div className="w-full max-w-xs space-y-1.5">
                  <div className="text-[10px] font-bold tracking-[0.25em] text-white/35 uppercase">Top scores</div>
                  {stats.highScores.slice(0, 3).map((h, i) => (
                    <div key={h.id} className="glass flex items-center gap-3 rounded-xl px-3.5 py-2">
                      <Award size={14} className={i === 0 ? "text-amber-300" : "text-white/35"} />
                      <span className="min-w-0 flex-1 truncate text-left text-xs font-semibold text-white/80">{h.taskName}</span>
                      <span className="font-mono2 text-xs font-bold text-amber-300">{h.score.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}

              <p className="font-mono2 text-[10px] leading-relaxed text-white/30">
                B tasks · 1 / 2 mode · SPACE start · P pause · R restart · M sound
              </p>
            </div>
          </div>
        )}

        {/* ================= SETUP ================= */}
        {phase === "setup" && (
          <div className="anim-pop no-scrollbar flex flex-1 flex-col gap-5 overflow-y-auto py-1">
            <div className="flex items-center justify-between">
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  sfx.click();
                  goPhase("menu");
                }}
                className="flex items-center gap-1 text-xs font-bold text-white/50 transition hover:text-white active:scale-95"
              >
                <ChevronLeft size={16} /> Menu
              </button>
              <span className="font-mono2 text-[10px] text-white/30">ESC</span>
            </div>

            <div>
              <label htmlFor="task-input" className="text-xs font-bold tracking-[0.2em] text-white/45 uppercase">
                Name your mission
              </label>
              <input
                id="task-input"
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
                maxLength={60}
                placeholder="e.g. Calculus problem set"
                autoFocus
                className="font-display mt-2 w-full rounded-2xl border border-white/12 bg-white/5 px-4 py-3.5 text-base font-semibold text-white placeholder-white/25 transition focus:border-amber-400/60"
              />
              {stats && stats.topTasks.length > 0 && (
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {stats.topTasks.slice(0, 6).map((t) => (
                    <button
                      key={t.name}
                      onClick={(e) => {
                        e.currentTarget.blur();
                        sfx.click();
                        setTaskName(t.name);
                      }}
                      className="max-w-36 truncate rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/60 transition hover:border-amber-400/40 hover:text-white active:scale-95"
                    >
                      {t.name}
                    </button>
                  ))}
                </div>
              )}
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  sfx.click();
                  setShowTasks(true);
                }}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-cyan-400/25 bg-cyan-400/8 px-4 py-3 text-xs font-bold text-cyan-200 transition hover:bg-cyan-400/15 active:scale-95"
              >
                <ClipboardList size={14} /> or pick from my task list
                {remainingTasks > 0 && <span className="font-mono2 text-cyan-300/70">({remainingTasks})</span>}
              </button>
            </div>

            <div>
              <span className="text-xs font-bold tracking-[0.2em] text-white/45 uppercase">Choose your weapon</span>
              <div className="mt-2 grid grid-cols-2 gap-3">
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    setMode("timer");
                  }}
                  className={`relative rounded-2xl border p-4 text-left transition active:scale-95 ${
                    mode === "timer"
                      ? "border-violet-400/60 bg-violet-400/10 shadow-[0_0_28px_rgba(167,139,250,0.18)]"
                      : "border-white/10 bg-white/4 hover:bg-white/7"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <TimerIcon size={22} className={mode === "timer" ? "text-violet-300" : "text-white/40"} />
                    <span className="font-mono2 text-[10px] text-white/30">KEY 1</span>
                  </div>
                  <div className="font-display mt-3 text-sm font-bold">Timer</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-white/45">Pomodoro focus rounds with breaks</div>
                </button>

                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    setMode("countdown");
                  }}
                  className={`relative rounded-2xl border p-4 text-left transition active:scale-95 ${
                    mode === "countdown"
                      ? "border-amber-400/60 bg-amber-400/10 shadow-[0_0_28px_rgba(251,191,36,0.15)]"
                      : "border-white/10 bg-white/4 hover:bg-white/7"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Clock size={22} className={mode === "countdown" ? "text-amber-300" : "text-white/40"} />
                    <span className="font-mono2 text-[10px] text-white/30">KEY 2</span>
                  </div>
                  <div className="font-display mt-3 text-sm font-bold">Countdown</div>
                  <div className="mt-0.5 text-[11px] leading-snug text-white/45">Straight countdown, your call</div>
                </button>
              </div>

              {mode === "countdown" && (
                <div className="anim-pop mt-3">
                  <span className="text-[11px] font-bold tracking-widest text-white/40 uppercase">How much time? (minutes)</span>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {DURATIONS.map((d) => (
                      <button
                        key={d}
                        onClick={(e) => {
                          e.currentTarget.blur();
                          sfx.click();
                          setDurationMin(d);
                        }}
                        className={`rounded-xl px-3 py-2 font-mono2 text-xs font-bold transition active:scale-90 ${
                          durationMin === d
                            ? "bg-amber-400 text-black shadow-[0_0_18px_rgba(251,191,36,0.35)]"
                            : "border border-white/10 bg-white/5 text-white/60 hover:bg-white/10"
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {mode === "timer" && (
                <div className="anim-pop mt-3">
                  <span className="text-[11px] font-bold tracking-widest text-white/40 uppercase">Minutes per round</span>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {TIMER_PRESETS.map((d) => (
                      <button
                        key={d}
                        onClick={(e) => {
                          e.currentTarget.blur();
                          sfx.click();
                          setPomoMinutes(d);
                        }}
                        className={`rounded-xl px-3 py-2 font-mono2 text-xs font-bold transition active:scale-90 ${
                          pomoMinutes === d
                            ? "bg-violet-400 text-black shadow-[0_0_18px_rgba(167,139,250,0.35)]"
                            : "border border-white/10 bg-white/5 text-white/60 hover:bg-white/10"
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                  <p className="mt-2.5 text-[11px] text-white/40">
                    {pomoMinutes}-minute focus rounds with 5-minute breaks. Finish all four for a massive bonus.
                  </p>
                </div>
              )}
            </div>

            <div className="mt-auto pt-2">
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  taskIdRef.current = null;
                  beginFocus();
                }}
                className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 font-display text-lg font-black tracking-wide text-black shadow-[0_10px_40px_rgba(251,146,60,0.35)] transition hover:brightness-110 active:scale-95"
              >
                <span className="relative flex items-center justify-center gap-2">
                  <Zap size={19} className="fill-black" /> BEGIN FOCUS
                </span>
              </button>
              <p className="font-mono2 mt-2.5 text-center text-[10px] tracking-[0.2em] text-white/30">
                ENTER BEGIN · T STATS
              </p>
            </div>
          </div>
        )}

        {/* ================= SESSION (focus / break / paused) ================= */}
        {inSession && (
          <>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    toggleMute();
                  }}
                  className="glass grid h-10 w-10 place-items-center rounded-xl text-white/70 transition hover:bg-white/10 active:scale-90"
                  aria-label={muted ? "Unmute" : "Mute"}
                >
                  {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </button>
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    setShowStats(true);
                  }}
                  className="glass grid h-10 w-10 place-items-center rounded-xl text-white/70 transition hover:bg-white/10 active:scale-90"
                  aria-label="Stats"
                >
                  <Trophy size={16} />
                </button>
              </div>

              <div className="glass relative flex items-center gap-2.5 overflow-visible rounded-2xl px-4 py-2">
                <Flame size={16} className="text-amber-400" />
                <span className="font-mono2 text-lg font-black text-amber-300 tabular-nums">{score.toLocaleString()}</span>
                <span
                  className={`rounded-md px-1.5 py-0.5 font-mono2 text-[11px] font-bold transition-colors ${
                    combo > 1 ? "bg-pink-500/20 text-pink-300" : "bg-white/8 text-white/40"
                  }`}
                >
                  x{combo.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="flex flex-1 items-center justify-center py-2">
              <div ref={ringBoxRef} className="w-full max-w-[340px]">
                <TimerRing
                  ref={ringRef}
                  variant={ringVariant}
                  label={ringLabel}
                  taskName={displayTask}
                  round={mode === "timer" ? { current: round, total: POMODORO_ROUNDS } : undefined}
                />
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pb-1.5">
              {phase === "focus" && (
                <>
                  <button
                    onClick={(e) => {
                      e.currentTarget.blur();
                      pauseSession();
                    }}
                    className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-7 py-3.5 font-display text-base font-black text-black shadow-[0_8px_30px_rgba(251,146,60,0.35)] transition hover:brightness-110 active:scale-95"
                  >
                    <Pause size={18} className="fill-black" /> PAUSE
                  </button>
                  <button
                    onClick={(e) => {
                      e.currentTarget.blur();
                      completeSession(false);
                    }}
                    className="glass rounded-2xl px-4 py-3.5 text-xs font-bold text-white/60 transition hover:bg-white/10 active:scale-95"
                  >
                    End
                  </button>
                </>
              )}
              {phase === "break" && (
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    advanceRound();
                  }}
                  className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-7 py-3.5 font-display text-base font-black text-black shadow-[0_8px_30px_rgba(34,211,238,0.3)] transition hover:brightness-110 active:scale-95"
                >
                  <Play size={18} className="fill-black" /> SKIP BREAK
                </button>
              )}
              {phase === "paused" && <div className="h-[52px]" />}
            </div>

            <p className="font-mono2 pb-1 text-center text-[10px] tracking-[0.22em] text-white/30">
              {phase === "break" ? "SPACE NEXT ROUND" : "SPACE PAUSE · T STATS"}
            </p>
          </>
        )}

        {/* pause overlay */}
        {phase === "paused" && (
          <div className="anim-pop absolute inset-0 z-40 flex flex-col items-center justify-center gap-6 bg-black/65 px-6 backdrop-blur-md">
            <div className="text-center">
              <div className="font-display text-4xl font-black tracking-wide">PAUSED</div>
              <p className="mt-1.5 text-sm text-white/50">Combo reset — the forge is cooling.</p>
            </div>
            <button
              onClick={(e) => {
                e.currentTarget.blur();
                resumeSession();
              }}
              className="flex w-full max-w-xs items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 font-display text-lg font-black text-black shadow-[0_10px_40px_rgba(251,146,60,0.35)] transition hover:brightness-110 active:scale-95"
            >
              <Play size={20} className="fill-black" /> RESUME
            </button>
            <div className="grid w-full max-w-xs grid-cols-2 gap-2.5">
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  completeSession(false);
                }}
                className="rounded-2xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm font-bold text-emerald-300 transition hover:bg-emerald-400/20 active:scale-95"
              >
                End &amp; Save
              </button>
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  sfx.click();
                  quitToMenu();
                }}
                className="flex items-center justify-center gap-1.5 rounded-2xl border border-white/12 bg-white/5 px-4 py-3 text-sm font-bold text-white/60 transition hover:bg-white/10 active:scale-95"
              >
                <Home size={15} /> Quit
              </button>
            </div>
            <p className="font-mono2 text-[10px] tracking-[0.2em] text-white/30">SPACE RESUME · R END · ESC MENU</p>
          </div>
        )}

        {/* ================= SUMMARY ================= */}
        {phase === "summary" && summary && (
          <div className="anim-pop no-scrollbar flex flex-1 flex-col items-center justify-center gap-4 overflow-y-auto py-2 text-center">
            <div className="relative">
              {summary.newHigh && (
                <div className="anim-wiggle absolute -top-9 left-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full border border-amber-400/50 bg-amber-400/15 px-3.5 py-1.5 text-[11px] font-black tracking-widest text-amber-300 uppercase">
                  <Sparkles size={13} /> New high score
                </div>
              )}
              <div
                className={`font-display text-4xl font-black tracking-tight sm:text-[2.6rem] ${
                  summary.completed ? "text-gradient" : "text-white/85"
                }`}
              >
                {summary.completed ? "SESSION COMPLETE" : "SESSION ENDED"}
              </div>
              <p className="mt-1.5 text-sm text-white/50">
                {summary.taskName} · {summary.mode === "timer" ? "Pomodoro Timer" : "Countdown"}
              </p>
            </div>

            <div className="anim-pop">
              <div className="text-[10px] font-bold tracking-[0.35em] text-white/40 uppercase">Score</div>
              <CountUp
                value={summary.score}
                className="font-mono2 text-6xl font-black text-amber-300 drop-shadow-[0_0_28px_rgba(251,191,36,0.35)]"
              />
              {summary.bonus > 0 && (
                <div className="mt-1 text-xs font-bold text-emerald-300">
                  includes +{summary.bonus.toLocaleString()} completion bonus
                </div>
              )}
              <div className="font-mono2 mt-1 text-[10px] tracking-[0.25em] text-white/30">
                {summary.saved ? "SAVED TO RECORDS" : "SAVING..."}
              </div>
            </div>

            <div className="grid w-full max-w-xs grid-cols-3 gap-2">
              <div className="glass rounded-2xl px-2 py-3">
                <div className="text-[9px] font-bold tracking-widest text-white/40 uppercase">Time</div>
                <div className="font-mono2 mt-1 text-sm font-bold text-cyan-300">{fmtDuration(summary.actualSeconds)}</div>
              </div>
              <div className="glass rounded-2xl px-2 py-3">
                <div className="text-[9px] font-bold tracking-widest text-white/40 uppercase">Best combo</div>
                <div className="font-mono2 mt-1 text-sm font-bold text-pink-300">x{bestCombo.toFixed(2)}</div>
              </div>
              <div className="glass rounded-2xl px-2 py-3">
                <div className="text-[9px] font-bold tracking-widest text-white/40 uppercase">Planned</div>
                <div className="font-mono2 mt-1 text-sm font-bold text-violet-300">{summary.plannedMinutes}m</div>
              </div>
            </div>

            {summary.taskId != null && !summary.taskDone && (
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  void markTaskDone();
                }}
                className="flex items-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 px-5 py-2.5 text-sm font-bold text-emerald-300 transition hover:bg-emerald-400/20 active:scale-95"
              >
                <Check size={15} /> Mark task as done
              </button>
            )}
            {summary.taskId != null && summary.taskDone && (
              <div className="anim-pop flex items-center gap-2 text-sm font-bold text-emerald-300">
                <Check size={15} /> Task completed — nice work
              </div>
            )}

            {stats && stats.today.sessions > 0 && (
              <div className="glass anim-pop flex items-center gap-2 rounded-2xl px-4 py-2.5 text-xs text-white/60">
                <Flame size={14} className="text-amber-300" />
                Today so far: <b className="font-mono2 text-amber-300">{fmtDuration(stats.today.totalSeconds)}</b>
                <span className="text-white/35">·</span>
                <b className="font-mono2 text-cyan-300">{stats.today.sessions}</b> sessions
              </div>
            )}

            <div className="flex w-full max-w-xs flex-col gap-2.5 pt-1">
              <button
                onClick={(e) => {
                  e.currentTarget.blur();
                  beginFocus();
                }}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 font-display text-lg font-black text-black shadow-[0_10px_40px_rgba(251,146,60,0.35)] transition hover:brightness-110 active:scale-95"
              >
                <RotateCcw size={19} /> STUDY AGAIN
              </button>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    goPhase("setup");
                  }}
                  className="rounded-2xl border border-white/12 bg-white/5 px-4 py-3 text-sm font-bold text-white/70 transition hover:bg-white/10 active:scale-95"
                >
                  Change Task
                </button>
                <button
                  onClick={(e) => {
                    e.currentTarget.blur();
                    sfx.click();
                    quitToMenu();
                  }}
                  className="flex items-center justify-center gap-1.5 rounded-2xl border border-white/12 bg-white/5 px-4 py-3 text-sm font-bold text-white/70 transition hover:bg-white/10 active:scale-95"
                >
                  <Home size={15} /> Menu
                </button>
              </div>
            </div>

            <p className="font-mono2 text-[10px] tracking-[0.2em] text-white/30">R INSTANT RESTART · T STATS</p>
          </div>
        )}
      </div>

      <FXCanvas ref={fxRef} intensityRef={intensityRef} shakeRef={shakeRef} />

      {showStats && <StatsPanel data={stats} onClose={() => setShowStats(false)} />}

      {showTasks && (
        <TaskPanel
          tasks={tasks}
          onClose={() => setShowTasks(false)}
          onAdd={addTask}
          onToggle={(id, done) => void toggleTask(id, done)}
          onDelete={(id) => void deleteTask(id)}
          onStart={startTask}
        />
      )}

      {/* decorative break icon */}
      {phase === "break" && (
        <div className="pointer-events-none fixed bottom-6 left-1/2 z-10 -translate-x-1/2">
          <Coffee size={20} className="animate-bounce text-cyan-300/60" />
        </div>
      )}
    </div>
  );
}
