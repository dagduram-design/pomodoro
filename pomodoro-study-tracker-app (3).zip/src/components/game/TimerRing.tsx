"use client";

import { forwardRef, useImperativeHandle, useRef } from "react";

export interface RingHandle {
  /** Called every animation frame — mutates DOM directly, zero re-renders. */
  set(remaining: number, total: number, elapsed: number): void;
}

interface Props {
  variant: "amber" | "violet" | "cyan";
  label: string;
  taskName: string;
  round?: { current: number; total: number };
}

const R = 138;
const CIRC = 2 * Math.PI * R;

const GRADIENTS: Record<Props["variant"], [string, string]> = {
  amber: ["#fbbf24", "#fb923c"],
  violet: ["#a78bfa", "#f472b6"],
  cyan: ["#22d3ee", "#34d399"],
};

function fmt(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

const TimerRing = forwardRef<RingHandle, Props>(function TimerRing({ variant, label, taskName, round }, ref) {
  const progressRef = useRef<SVGCircleElement | null>(null);
  const glowRef = useRef<SVGCircleElement | null>(null);
  const timeRef = useRef<HTMLDivElement | null>(null);
  const elapsedRef = useRef<HTMLDivElement | null>(null);
  const lastSec = useRef(-1);

  useImperativeHandle(ref, () => ({
    set(remaining, total, elapsed) {
      const p = total > 0 ? Math.max(0, Math.min(1, remaining / total)) : 0;
      const offset = CIRC * (1 - p);
      progressRef.current?.setAttribute("stroke-dashoffset", offset.toFixed(2));
      glowRef.current?.setAttribute("stroke-dashoffset", offset.toFixed(2));
      const sec = Math.ceil(remaining);
      if (sec !== lastSec.current) {
        lastSec.current = sec;
        if (timeRef.current) timeRef.current.textContent = fmt(remaining);
        if (elapsedRef.current) elapsedRef.current.textContent = `ELAPSED ${fmt(elapsed)}`;
      }
    },
  }));

  const [c1, c2] = GRADIENTS[variant];
  const ticks = Array.from({ length: 60 }, (_, i) => i);

  return (
    <div className="relative aspect-square w-full max-w-[340px]">
      {/* breathing glow */}
      <div
        className="anim-breathe absolute inset-6 rounded-full blur-3xl"
        style={{ background: `radial-gradient(circle, ${c1}33 0%, ${c2}14 55%, transparent 75%)` }}
      />
      <svg viewBox="0 0 320 320" className="relative h-full w-full -rotate-90">
        <defs>
          <linearGradient id={`ring-${variant}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={c1} />
            <stop offset="100%" stopColor={c2} />
          </linearGradient>
        </defs>

        {/* tick marks */}
        <g className="anim-spin-slower" style={{ transformOrigin: "160px 160px" }}>
          {ticks.map((i) => {
            const a = (i / 60) * Math.PI * 2;
            const inner = i % 5 === 0 ? 118 : 124;
            const x1 = 160 + Math.cos(a) * inner;
            const y1 = 160 + Math.sin(a) * inner;
            const x2 = 160 + Math.cos(a) * 130;
            const y2 = 160 + Math.sin(a) * 130;
            return (
              <line
                key={i}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={i % 5 === 0 ? "rgba(255,255,255,0.28)" : "rgba(255,255,255,0.1)"}
                strokeWidth={i % 5 === 0 ? 2 : 1}
                strokeLinecap="round"
              />
            );
          })}
        </g>

        {/* track */}
        <circle cx="160" cy="160" r={R} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="10" />

        {/* glow underlay */}
        <circle
          ref={glowRef}
          cx="160"
          cy="160"
          r={R}
          fill="none"
          stroke={`url(#ring-${variant})`}
          strokeWidth="18"
          strokeLinecap="round"
          strokeDasharray={CIRC}
          strokeDashoffset={0}
          opacity="0.25"
          style={{ filter: "blur(6px)" }}
        />

        {/* progress */}
        <circle
          ref={progressRef}
          cx="160"
          cy="160"
          r={R}
          fill="none"
          stroke={`url(#ring-${variant})`}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={CIRC}
          strokeDashoffset={0}
        />
      </svg>

      {/* center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 px-8 text-center">
        <span
          className="rounded-full border px-3 py-1 text-[11px] font-bold tracking-[0.22em] uppercase"
          style={{ borderColor: `${c1}55`, color: c1, background: `${c1}14` }}
        >
          {label}
        </span>
        <div
          ref={timeRef}
          className="font-mono2 text-[3.4rem] leading-none font-bold tabular-nums text-white drop-shadow-[0_0_18px_rgba(255,255,255,0.25)] sm:text-[3.8rem]"
        >
          00:00
        </div>
        <div ref={elapsedRef} className="font-mono2 text-[11px] tracking-[0.18em] text-white/40 uppercase">
          Elapsed 00:00
        </div>
        <div className="mt-1 max-w-full truncate text-sm font-semibold text-white/80">{taskName}</div>
        {round && (
          <div className="mt-1.5 flex items-center gap-1.5">
            {Array.from({ length: round.total }, (_, i) => (
              <span
                key={i}
                className="h-1.5 w-5 rounded-full transition-all duration-500"
                style={{
                  background: i < round.current ? c1 : "rgba(255,255,255,0.14)",
                  boxShadow: i < round.current ? `0 0 8px ${c1}88` : undefined,
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
});

export default TimerRing;
