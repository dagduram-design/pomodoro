"use client";

import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";

/* ------------------------------------------------------------------ */
/*  SoundFX — tiny synthesized sound engine (no assets needed)         */
/* ------------------------------------------------------------------ */

type OscType = OscillatorType;

class SoundFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  enabled = true;

  unlock() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.45;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setEnabled(v: boolean) {
    this.enabled = v;
  }

  private tone(freq: number, dur: number, type: OscType = "sine", vol = 0.2, when = 0, slideTo?: number) {
    if (!this.enabled || !this.ctx || !this.master) return;
    const t0 = this.ctx.currentTime + when;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freq), t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(vol, t0 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  click() {
    this.tone(700, 0.06, "square", 0.07);
  }
  start() {
    [523, 659, 784].forEach((f, i) => this.tone(f, 0.13, "triangle", 0.11, i * 0.07));
  }
  milestone() {
    this.tone(660, 0.1, "triangle", 0.13);
    this.tone(990, 0.18, "triangle", 0.11, 0.08);
  }
  comboUp() {
    this.tone(440, 0.08, "square", 0.06);
    this.tone(660, 0.12, "square", 0.06, 0.06);
  }
  comboLost() {
    this.tone(420, 0.22, "sawtooth", 0.09, 0, 90);
  }
  pause() {
    this.tone(320, 0.22, "sawtooth", 0.07, 0, 130);
  }
  resume() {
    this.tone(300, 0.1, "triangle", 0.09, 0, 520);
  }
  breakStart() {
    [784, 659, 523].forEach((f, i) => this.tone(f, 0.16, "sine", 0.1, i * 0.1));
  }
  complete() {
    [523, 659, 784, 1046, 1318, 1568].forEach((f, i) => this.tone(f, 0.24, "triangle", 0.12, i * 0.09));
  }
  gameOver() {
    [392, 330, 262].forEach((f, i) => this.tone(f, 0.22, "triangle", 0.1, i * 0.12));
  }
  count() {
    this.tone(880, 0.09, "square", 0.08);
  }
}

export const sfx = new SoundFX();

/* ------------------------------------------------------------------ */
/*  FXCanvas — particles + screen shake driven by one rAF loop         */
/* ------------------------------------------------------------------ */

export interface FXHandle {
  burst(x: number, y: number, count?: number, power?: number): void;
  shake(magnitude: number): void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  gravity: number;
  drag: number;
  shape: "dot" | "rect";
  rot: number;
  vrot: number;
  sway: number;
}

const COLORS = ["#fbbf24", "#22d3ee", "#a78bfa", "#f472b6", "#34d399", "#fb923c"];

function makeEmber(w: number, h: number): Particle {
  return {
    x: Math.random() * w,
    y: h + 12,
    vx: (Math.random() - 0.5) * 22,
    vy: -28 - Math.random() * 55,
    life: 4 + Math.random() * 4,
    maxLife: 8,
    size: 0.8 + Math.random() * 2.1,
    color: COLORS[(Math.random() * COLORS.length) | 0],
    gravity: -5,
    drag: 0.996,
    shape: "dot",
    rot: 0,
    vrot: 0,
    sway: Math.random() * Math.PI * 2,
  };
}

interface Props {
  intensityRef: { current: number };
  shakeRef: { current: HTMLDivElement | null };
}

const FXCanvas = forwardRef<FXHandle, Props>(function FXCanvas({ intensityRef, shakeRef }, ref) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particles = useRef<Particle[]>([]);
  const shakeMag = useRef(0);

  useImperativeHandle(ref, () => ({
    burst(x, y, count = 36, power = 1) {
      const arr = particles.current;
      for (let i = 0; i < count; i++) {
        const ang = Math.random() * Math.PI * 2;
        const sp = (110 + Math.random() * 330) * power;
        arr.push({
          x,
          y,
          vx: Math.cos(ang) * sp,
          vy: Math.sin(ang) * sp - 70,
          life: 0.7 + Math.random() * 0.9,
          maxLife: 1.4,
          size: 2 + Math.random() * 3.6,
          color: COLORS[(Math.random() * COLORS.length) | 0],
          gravity: 330,
          drag: 0.986,
          shape: Math.random() < 0.45 ? "rect" : "dot",
          rot: Math.random() * Math.PI,
          vrot: (Math.random() - 0.5) * 14,
          sway: 0,
        });
      }
      if (arr.length > 420) arr.splice(0, arr.length - 420);
    },
    shake(m) {
      shakeMag.current = Math.min(26, Math.max(shakeMag.current, m));
    },
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0;
    let h = 0;
    let raf = 0;
    let last = performance.now();

    const resize = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      // Ambient embers
      const intensity = intensityRef.current;
      if (intensity > 0 && particles.current.length < 240 && Math.random() < intensity * dt * 12) {
        particles.current.push(makeEmber(w, h));
      }

      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";

      const arr = particles.current;
      for (let i = arr.length - 1; i >= 0; i--) {
        const p = arr[i];
        p.life -= dt;
        if (p.life <= 0) {
          arr.splice(i, 1);
          continue;
        }
        p.vy += p.gravity * dt;
        const drag = Math.pow(p.drag, dt * 60);
        p.vx *= drag;
        p.vy *= drag;
        p.x += p.vx * dt + (p.sway ? Math.sin(now / 420 + p.sway) * 14 * dt : 0);
        p.y += p.vy * dt;
        p.rot += p.vrot * dt;

        const a = Math.max(0, Math.min(1, p.life / (p.maxLife * 0.55)));
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        if (p.shape === "rect") {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillRect(-p.size, -p.size * 0.6, p.size * 2, p.size * 1.2);
          ctx.restore();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";

      // Screen shake
      const el = shakeRef.current;
      if (el) {
        if (shakeMag.current > 0.15) {
          const m = shakeMag.current;
          const x = (Math.random() * 2 - 1) * m;
          const y = (Math.random() * 2 - 1) * m;
          const r = (Math.random() * 2 - 1) * m * 0.12;
          el.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px) rotate(${r.toFixed(2)}deg)`;
          shakeMag.current *= Math.pow(0.002, dt);
        } else if (el.style.transform) {
          el.style.transform = "";
        }
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [intensityRef, shakeRef]);

  return <canvas ref={canvasRef} aria-hidden="true" className="pointer-events-none fixed inset-0 z-20" />;
});

export default FXCanvas;
