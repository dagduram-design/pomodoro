import { db } from "@/db";
import { tasks } from "@/db/schema";
import { getLocalUserId } from "@/lib/local";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const userId = await getLocalUserId();

  const rows = await db
    .select()
    .from(tasks)
    .where(eq(tasks.userId, userId))
    .orderBy(asc(tasks.done), desc(tasks.createdAt))
    .limit(500);

  return Response.json(rows);
}

export async function POST(req: Request) {
  const userId = await getLocalUserId();

  const body = await req.json().catch(() => null);
  const name = String(body?.name ?? "").trim().slice(0, 80);
  if (!name) return Response.json({ error: "Task name is required." }, { status: 400 });

  const [row] = await db.insert(tasks).values({ userId, name }).returning();
  return Response.json(row, { status: 201 });
}
