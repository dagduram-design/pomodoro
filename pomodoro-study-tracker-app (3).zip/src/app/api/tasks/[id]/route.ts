import { db } from "@/db";
import { tasks } from "@/db/schema";
import { getLocalUserId } from "@/lib/local";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Params) {
  const userId = await getLocalUserId();

  const { id } = await params;
  const taskId = Number(id);
  if (!Number.isInteger(taskId)) return Response.json({ error: "Invalid task id." }, { status: 400 });

  const body = await req.json().catch(() => null);
  const done = Boolean(body?.done);

  const [row] = await db
    .update(tasks)
    .set({ done, completedAt: done ? new Date() : null })
    .where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)))
    .returning();

  if (!row) return Response.json({ error: "Task not found." }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: Request, { params }: Params) {
  const userId = await getLocalUserId();

  const { id } = await params;
  const taskId = Number(id);
  if (!Number.isInteger(taskId)) return Response.json({ error: "Invalid task id." }, { status: 400 });

  await db.delete(tasks).where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)));
  return Response.json({ ok: true });
}
