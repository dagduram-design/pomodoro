import { db } from "@/db";
import { studySessions, tasks } from "@/db/schema";
import { getLocalUserId } from "@/lib/local";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const DAY_MS = 86_400_000;

function dateKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export async function GET() {
  try {
    const userId = await getLocalUserId();

    const rows = await db
      .select()
      .from(studySessions)
      .where(eq(studySessions.userId, userId))
      .orderBy(desc(studySessions.createdAt))
      .limit(2000);

    const taskRows = await db
      .select({ done: tasks.done, completedAt: tasks.completedAt })
      .from(tasks)
      .where(eq(tasks.userId, userId))
      .limit(2000);

    interface DayAgg {
      totalSeconds: number;
      sessions: number;
      score: number;
      tasks: Map<string, number>;
    }

    const byDay = new Map<string, DayAgg>();

    for (const r of rows) {
      const key = dateKey(r.createdAt);
      let d = byDay.get(key);
      if (!d) {
        d = { totalSeconds: 0, sessions: 0, score: 0, tasks: new Map<string, number>() };
        byDay.set(key, d);
      }
      d.totalSeconds += r.actualSeconds;
      d.sessions += 1;
      d.score += r.score;
      d.tasks.set(r.taskName, (d.tasks.get(r.taskName) ?? 0) + r.actualSeconds);
    }

    // Tasks completed per day (for the History section)
    const tasksDoneByDay = new Map<string, number>();
    for (const t of taskRows) {
      if (t.done && t.completedAt) {
        const key = dateKey(t.completedAt);
        tasksDoneByDay.set(key, (tasksDoneByDay.get(key) ?? 0) + 1);
      }
    }

    const now = new Date();
    const todayKey = dateKey(now);

    const todayAgg = byDay.get(todayKey);
    const today = {
      totalSeconds: todayAgg?.totalSeconds ?? 0,
      sessions: todayAgg?.sessions ?? 0,
      tasks: todayAgg
        ? [...todayAgg.tasks.entries()]
            .map(([name, seconds]) => ({ name, seconds }))
            .sort((a, b) => b.seconds - a.seconds)
            .slice(0, 6)
        : [],
    };

    // Last 7 days, oldest -> newest
    const week: { key: string; label: string; totalSeconds: number; sessions: number; isToday: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * DAY_MS);
      const key = dateKey(d);
      const agg = byDay.get(key);
      week.push({
        key,
        label: d.toLocaleDateString("en-US", { weekday: "narrow" }),
        totalSeconds: agg?.totalSeconds ?? 0,
        sessions: agg?.sessions ?? 0,
        isToday: key === todayKey,
      });
    }

    // Consecutive-day streak (today counts once you study; yesterday keeps it alive)
    let streak = 0;
    let cursor = new Date(now.getTime());
    if (!byDay.has(todayKey)) cursor = new Date(now.getTime() - DAY_MS);
    while (byDay.has(dateKey(cursor))) {
      streak++;
      cursor = new Date(cursor.getTime() - DAY_MS);
    }

    // Date records, newest first — with per-task minutes and tasks done that day
    const history = [...byDay.entries()]
      .sort((a, b) => (a[0] < b[0] ? 1 : -1))
      .slice(0, 60)
      .map(([date, agg]) => ({
        date,
        totalSeconds: agg.totalSeconds,
        sessions: agg.sessions,
        topTask: [...agg.tasks.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "",
        tasks: [...agg.tasks.entries()]
          .map(([name, seconds]) => ({ name, seconds }))
          .sort((a, b) => b.seconds - a.seconds)
          .slice(0, 6),
        tasksDone: tasksDoneByDay.get(date) ?? 0,
      }));

    // Most-studied tasks of all time (quick-pick chips on setup screen)
    const taskTotals = new Map<string, number>();
    for (const r of rows) taskTotals.set(r.taskName, (taskTotals.get(r.taskName) ?? 0) + r.actualSeconds);
    const topTasks = [...taskTotals.entries()]
      .map(([name, seconds]) => ({ name, seconds }))
      .sort((a, b) => b.seconds - a.seconds)
      .slice(0, 8);

    const highScores = [...rows]
      .sort((a, b) => b.score - a.score)
      .slice(0, 8)
      .map((r) => ({
        id: r.id,
        taskName: r.taskName,
        mode: r.mode,
        plannedMinutes: r.plannedMinutes,
        actualSeconds: r.actualSeconds,
        score: r.score,
        createdAt: r.createdAt.toISOString(),
      }));

    const allTimeSeconds = rows.reduce((s, r) => s + r.actualSeconds, 0);
    const totalSessions = rows.length;

    return Response.json({
      today,
      week,
      streak,
      history,
      topTasks,
      highScores,
      allTimeSeconds,
      totalSessions,
    });
  } catch (err) {
    console.error("Failed to load stats", err);
    return Response.json({ error: "Failed to load stats" }, { status: 500 });
  }
}
