import { db } from "@/db";
import { studySessions } from "@/db/schema";
import { getLocalUserId } from "@/lib/local";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const userId = await getLocalUserId();

    const body = await req.json();

    const taskName = String(body.taskName ?? "").trim().slice(0, 80) || "Untitled Task";
    const mode = body.mode === "countdown" ? "countdown" : "timer";
    const plannedMinutes = Math.max(1, Math.min(600, Math.round(Number(body.plannedMinutes) || 0)));
    const actualSeconds = Math.max(0, Math.min(60 * 60 * 12, Math.round(Number(body.actualSeconds) || 0)));
    const completed = Boolean(body.completed);
    const score = Math.max(0, Math.min(1_000_000, Math.round(Number(body.score) || 0)));
    const taskId = Number.isFinite(Number(body.taskId)) ? Math.round(Number(body.taskId)) : null;

    const [row] = await db
      .insert(studySessions)
      .values({ userId, taskId, taskName, mode, plannedMinutes, actualSeconds, completed, score })
      .returning();

    return Response.json(row, { status: 201 });
  } catch (err) {
    console.error("Failed to save session", err);
    return Response.json({ error: "Failed to save session" }, { status: 500 });
  }
}
