import StudyGame from "@/components/game/StudyGame";

export default function HomePage() {
  return (
    <main className="fixed inset-0 overflow-hidden bg-[#07060e]">
      <StudyGame />
    </main>
  );
}
