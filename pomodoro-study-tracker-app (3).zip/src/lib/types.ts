export interface SessionUser {
  id: number;
  username: string;
}

export type TimerMode = "timer" | "countdown";

export interface TaskItem {
  id: number;
  name: string;
  done: boolean;
  createdAt: string;
}
