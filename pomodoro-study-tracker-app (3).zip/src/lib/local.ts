import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

/**
 * No sign-in required: all data is saved locally under a single built-in
 * profile. This lazily creates the local profile on first use.
 */
export async function getLocalUserId(): Promise<number> {
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.username, "local")).limit(1);
  if (existing[0]) return existing[0].id;

  try {
    const [row] = await db
      .insert(users)
      .values({ username: "local", passwordHash: "local" })
      .returning({ id: users.id });
    return row.id;
  } catch {
    // Lost a race with a concurrent create — re-read.
    const again = await db.select({ id: users.id }).from(users).where(eq(users.username, "local")).limit(1);
    return again[0].id;
  }
}
